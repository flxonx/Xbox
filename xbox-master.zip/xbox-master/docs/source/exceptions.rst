Exceptions
============

.. autoexception:: xbox.exceptions.XboxException

.. autoexception:: xbox.exceptions.AuthenticationException

.. autoexception:: xbox.exceptions.InvalidRequest

.. autoexception:: xbox.exceptions.NotFoundException

.. autoexception:: xbox.exceptions.GamertagNotFound

.. autoexception:: xbox.exceptions.ClipNotFound
